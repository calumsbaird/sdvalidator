SPF and DMARC validator

## Documentation

<http://www.csbaird.com/software/sdvalidator>

## TODO

- Better processing for DMARC records
- bug with redirect.  Fix REGEX eg 'gmail.com'
