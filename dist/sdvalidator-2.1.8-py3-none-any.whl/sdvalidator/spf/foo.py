print('123`:xhello from', __name__)
