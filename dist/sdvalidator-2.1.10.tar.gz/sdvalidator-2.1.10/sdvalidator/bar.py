print('hello from bar.py', __name__)
