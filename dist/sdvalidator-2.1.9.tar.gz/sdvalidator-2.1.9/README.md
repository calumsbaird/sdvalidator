# SPF and DMARC validator

This link helped <https://stackoverflow.com/questions/39280326/python-entry-point-console-scripts-not-found>

## TODO
- Better processing for DMARC records
- docs


