import tldextract

def clean_domains(domains):

    pass
